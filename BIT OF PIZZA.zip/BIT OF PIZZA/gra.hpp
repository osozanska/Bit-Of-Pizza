#ifndef GRA_H
#define GRA_H

void UruchomGre(Texture2D tloGry);

#endif 
